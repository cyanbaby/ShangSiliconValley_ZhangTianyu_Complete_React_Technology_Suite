/*
 * @Date: 2023-03-25 17:45:57
 */
export default function News() {
  return (
    <ul>
      <li>news001</li>
      <li>news002</li>
      <li>news003</li>
    </ul>
  )
}
